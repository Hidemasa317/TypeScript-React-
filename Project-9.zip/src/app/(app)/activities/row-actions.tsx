'use client';

import Link from 'next/link';
import { useRouter } from 'next/navigation';

export default function RowActivityActions({ id }: { id: string }) {
  const router = useRouter();

  async function onActivityDelete() {
    if (!confirm('本当に削除しますか？')) return;

    const res = await fetch(`/api/activities/${id}`, {
      method: 'DELETE',
    });

    if (!res.ok) {
      alert('削除に失敗しました');
      return;
    }

    router.refresh(); // 一覧再取得
  }

  return (
    <div className="flex gap-4">
      <Link
        href={`/activities/${id}/edit`}
        className="text-indigo-600 hover:underline"
      >
        編集
      </Link>

      <button
        onClick={onActivityDelete}
        className="text-red-600 hover:underline"
      >
        削除
      </button>
    </div>
  );
}
