'use client';

import Link from 'next/link';
import { useRouter } from 'next/navigation';

export default function RowCtcActions({ id }: { id: string }) {
  const router = useRouter();

  async function oncontactDelete() {
    if (!confirm('本当に削除しますか？')) return;

    const res = await fetch(`/api/contacts/${id}`, {
      method: 'DELETE',
    });

    if (!res.ok) {
      alert('削除に失敗しました');
      return;
    }

    router.refresh(); // 一覧再取得
  }

  return (
    <div className="flex gap-4">
      <Link
        href={`/contacts/${id}/edit`}
        className="text-indigo-600 hover:underline"
      >
        編集
      </Link>

      <button
        onClick={oncontactDelete}
        className="text-red-600 hover:underline"
      >
        削除
      </button>
    </div>
  );
}
